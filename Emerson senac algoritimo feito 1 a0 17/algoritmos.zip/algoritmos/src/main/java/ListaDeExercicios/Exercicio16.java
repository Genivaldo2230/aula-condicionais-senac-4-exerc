/*Leia a hora inicial e a hora final de um jogo. A seguir calcule a duração do jogo, sabendo que o mesmo pode 
começar em um dia e terminar em outro, tendo uma duração mínima de 1 hora e máxima de 24 horas. Veja 
abaixo alguns exemplos.*/
package ListaDeExercicios;
import java.util.Scanner;

public class Exercicio16 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        double horaInicial, horaFinal, duraçaoJogo;
        
        System.out.println("Duração do jogo");
        System.out.println("Digite a hora inicial: ");
        horaInicial = input.nextDouble();
        System.out.println("Digite a hora final: ");
        horaFinal = input.nextDouble();
        
        //calculo da duração do jogo
        
        
   
        
    }
    
}
